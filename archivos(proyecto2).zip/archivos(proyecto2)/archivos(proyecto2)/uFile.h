//---------------------------------------------------------------------------

#ifndef uFileH
#define uFileH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.Menus.hpp>

#include <FStream>
//---------------------------------------------------------------------------
struct TFecha {
  byte dia;
  byte mes;
  Word a�o;
};
struct RegAlumno {
  char mark;
  Word cod;
  char nom[21];
  char dir[21];
  TFecha fecha;
};
struct RegIdxCod {
	Word cod;
	Cardinal pos;
};
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TEdit *Edit1;
	TEdit *Edit2;
	TEdit *Edit3;
	TLabel *Label4;
	TMaskEdit *MaskEdit1;
	TButton *Button1;
	TButton *Button2;
	TButton *Button3;
	TLabel *Label5;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Edit1Exit(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
	 fstream *pf, *pIdx;
	 AnsiString nmFile,nmIndexCod;
public:		// User declarations
	void limpiar();

	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
