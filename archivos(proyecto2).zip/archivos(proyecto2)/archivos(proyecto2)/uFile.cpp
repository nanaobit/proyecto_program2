//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uFile.h"
#include <iostream>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}

//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{

   nmFile ="Alumnos.dat";
   fstream f(nmFile.c_str(), ios::in|ios::binary);
   if (f.fail()) {
	  fstream f(nmFile.c_str(), ios::out|ios::binary);
   }
   f.close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Edit1Exit(TObject *Sender)
{
	 bool sw = false;
	 RegAlumno reg;
	 Word cod;
	 cod =StrToInt(Edit1->Text);
	 fstream f(nmFile.c_str(), ios::in|ios::binary);
	 if (f.is_open()) {
		do {
		  f.read((char*)&reg, sizeof(reg));
		  sw = (reg.cod==cod)&&(reg.mark!='*');
		}while(!sw && !f.eof());
		if (sw) {
		  Edit2->Text =reg.nom;
		  Edit3->Text =reg.dir;
		  AnsiString d, m, a;
		  d =IntToStr(reg.fecha.dia);
		  m =IntToStr(reg.fecha.mes);
		  a =IntToStr(reg.fecha.a�o);
		  MaskEdit1->Text =d+'/'+m+'/'+a;
		  Edit2->SetFocus();
		}else{
		  Edit2->Text ="";Edit3->Text ="";
		  MaskEdit1->Text ="";
		}
	 }
	 f.close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	 bool sw=false;
	 AnsiString cad;
	 RegAlumno reg, regNew;

	 regNew.mark='0';
	 regNew.cod =StrToInt(Edit1->Text);
	 cad =Edit2->Text;
	 strcpy(regNew.nom, cad.c_str());
	 cad =Edit3->Text;
	 strcpy(regNew.dir, cad.c_str());
	 cad =MaskEdit1->Text;
	 regNew.fecha.dia =StrToInt(cad.SubString(1, 2));
	 regNew.fecha.mes =StrToInt(cad.SubString(4, 2));
	 regNew.fecha.a�o =StrToInt(cad.SubString(7, 4));
	 fstream f(nmFile.c_str(), ios::in|ios::out|ios::binary);

	 if (f.is_open()) {
		 do{
			f.read((char*)&reg, sizeof(reg));
			sw =(reg.cod==regNew.cod)&&(reg.mark==regNew.mark);
		 }while(!sw && !f.eof());
		 if (sw)
		   f.seekg(-sizeof(reg), ios::cur);
		 else
		   f.seekg(0, ios::end);
		 f.write((char *)&regNew, sizeof(regNew));
		 Edit1->Text ="";Edit2->Text="";
		 Edit3->Text="";
		 Edit1->SetFocus();
	 }
	 f.close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
     Edit1->Text ="";
	 Edit2->Text ="";
	 Edit3->Text ="";
	 MaskEdit1->Text ="";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
	 ShowMessage("alumno eliminado!!");
	 Edit1->Text ="";
	 Edit2->Text ="";
	 Edit3->Text ="";
	 MaskEdit1->Text ="";
}
//---------------------------------------------------------------------------

